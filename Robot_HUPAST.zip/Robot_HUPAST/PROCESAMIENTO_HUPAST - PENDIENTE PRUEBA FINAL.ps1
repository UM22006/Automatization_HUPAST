﻿
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
Add-Type -AssemblyName System.Windows.Forms

Write-Host ""
Write-Host "======================================================"
Write-Host " P10 - PROCESAMIENTO MULTI OUTBOUND"
Write-Host "======================================================"
Write-Host ""
Write-Host "Metodo:"
Write-Host "  1. Leer ALV UNA SOLA VEZ"
Write-Host "  2. Crear lista de materiales pendientes"
Write-Host "  3. Recorrer la lista usando la misma secuencia de P4"
Write-Host "  4. Verificar pendientes al terminar"
Write-Host "  5. Si queda algo, hacer UNA pasada de recuperacion"
Write-Host "  6. Verificar nuevamente y detenerse"
Write-Host ""
Write-Host "P9 abre el Outbound en SAP y luego ejecuta el motor estable P7.1."
Write-Host ""

$archivo = "C:\Robot_HUPAST\resultado_p10.txt"

# ============================================================
# TIEMPOS
# ============================================================

$esperaAntesMaterial = 500
$esperaDespuesClick = 300
$esperaDespuesEscribirMaterial = 500
$esperaDespuesEnterMaterial = 1000
$esperaAntesQty = 300
$esperaDespuesQty = 500
$esperaDespuesPacking = 1500

# Espera antes de las verificaciones
$esperaAntesVerificacion = 5000

# ============================================================
# API WIN32
# ============================================================

Add-Type @"
using System;
using System.Runtime.InteropServices;

public class Win32P5
{
    [DllImport("user32.dll")]
    public static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

    [DllImport("user32.dll")]
    public static extern bool SetCursorPos(int X, int Y);

    [DllImport("user32.dll")]
    public static extern void mouse_event(
        uint dwFlags,
        uint dx,
        uint dy,
        uint dwData,
        UIntPtr dwExtraInfo
    );

    public const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
    public const uint MOUSEEVENTF_LEFTUP   = 0x0004;
}
"@

function Click-Mouse {

    param(
        [int]$X,
        [int]$Y
    )

    [Win32P5]::SetCursorPos($X, $Y) | Out-Null

    Start-Sleep -Milliseconds 200

    [Win32P5]::mouse_event(
        [Win32P5]::MOUSEEVENTF_LEFTDOWN,
        0,0,0,
        [UIntPtr]::Zero
    )

    Start-Sleep -Milliseconds 80

    [Win32P5]::mouse_event(
        [Win32P5]::MOUSEEVENTF_LEFTUP,
        0,0,0,
        [UIntPtr]::Zero
    )
}

function Log {

    param([string]$Texto)

    "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') | $Texto" |
        Out-File $archivo -Append -Encoding UTF8
}


# ============================================================
# P7 - IMPRESION Y GUARDADO FINAL
#
# Se ejecuta UNICAMENTE cuando la verificacion confirma
# que Qty not pckd = 0.
#
# Secuencia:
#   F5 -> esperar Print: -> CTRL+P -> confirmar cierre
#   -> volver a Packing Station -> CTRL+S
# ============================================================

function Finalizar-OutboundP7 {

    param(
        $SAP,
        [IntPtr]$HandleSAP
    )

    Write-Host ""
    Write-Host "======================================================"
    Write-Host " P7.1 - IMPRESION Y GUARDADO"
    Write-Host "======================================================"
    Write-Host ""

    Log "P7.1 - inicio impresion y guardado"

    # Activar Packing Station
    try {
        [Win32P5]::ShowWindow($HandleSAP, 9) | Out-Null
        Start-Sleep -Milliseconds 500
        [Win32P5]::SetForegroundWindow($HandleSAP) | Out-Null
        Start-Sleep -Milliseconds 800
    }
    catch {
        Write-Host "ERROR: No se pudo activar Packing Station."
        Log "P7.1 ERROR - no se pudo activar Packing Station"
        return $false
    }

    # Abrir menu de impresion
    Write-Host "Abriendo menu de impresion con F5..."
    Log "P7.1 - enviando F5"
    [System.Windows.Forms.SendKeys]::SendWait("{F5}")

    # Dar tiempo a SAP para crear el dialogo
    Start-Sleep -Seconds 3

    Write-Host "Buscando ventana Print: ..."

    $rootP71 = [System.Windows.Automation.AutomationElement]::RootElement
    $ventanaPrintP71 = $null

    # PRIMERA REVISION:
    # Buscar entre todos los hijos del escritorio, sin exigir ControlType.Window.
    try {
        $elementosRaizP71 =
            $rootP71.FindAll(
                [System.Windows.Automation.TreeScope]::Children,
                [System.Windows.Automation.Condition]::TrueCondition
            )

        foreach ($elementoP71 in $elementosRaizP71) {
            try {
                if (
                    $elementoP71.Current.Name -match "^Print:" -and
                    $elementoP71.Current.ClassName -eq "#32770"
                ) {
                    $ventanaPrintP71 = $elementoP71
                    break
                }
            }
            catch {}
        }
    }
    catch {}

    # PLAN B DE LA MISMA REVISION:
    # SAP puede exponer Print: como descendiente de Packing Station.
    if ($null -eq $ventanaPrintP71) {
        try {
            $descendientesP71 =
                $SAP.FindAll(
                    [System.Windows.Automation.TreeScope]::Descendants,
                    [System.Windows.Automation.Condition]::TrueCondition
                )

            foreach ($elementoP71 in $descendientesP71) {
                try {
                    if (
                        $elementoP71.Current.Name -match "^Print:" -and
                        $elementoP71.Current.ClassName -eq "#32770"
                    ) {
                        $ventanaPrintP71 = $elementoP71
                        break
                    }
                }
                catch {}
            }
        }
        catch {}
    }

    if ($null -eq $ventanaPrintP71) {
        Write-Host ""
        Write-Host "ERROR: No se encontro la ventana Print:."
        Write-Host "NO se enviara CTRL+P."
        Write-Host "NO se enviara CTRL+S."
        Write-Host ""
        Log "P7.1 ERROR - ventana Print no encontrada"
        return $false
    }

    Write-Host "Ventana Print: encontrada."
    Log "P7.1 - ventana Print encontrada"

    # Activar el dialogo Print
    try {
        $handlePrintP71 =
            [IntPtr]$ventanaPrintP71.Current.NativeWindowHandle

        if ($handlePrintP71 -ne [IntPtr]::Zero) {
            [Win32P5]::ShowWindow($handlePrintP71, 9) | Out-Null
            Start-Sleep -Milliseconds 300
            [Win32P5]::SetForegroundWindow($handlePrintP71) | Out-Null
            Start-Sleep -Milliseconds 700
        }
        else {
            # Si UI Automation no entrega handle, intentar foco por UIA.
            $ventanaPrintP71.SetFocus()
            Start-Sleep -Milliseconds 700
        }
    }
    catch {
        Write-Host "ERROR: No se pudo activar la ventana Print:."
        Write-Host "NO se enviara CTRL+P ni CTRL+S."
        Log "P7.1 ERROR - no se pudo activar Print"
        return $false
    }

    # Imprimir mediante el atajo ya probado manualmente
    Write-Host "Enviando CTRL+P..."
    Log "P7.1 - enviando CTRL+P"
    [System.Windows.Forms.SendKeys]::SendWait("^p")

    # Espera simple, sin segunda comprobacion del dialogo
    Write-Host "Esperando finalizacion de impresion..."
    Start-Sleep -Seconds 3

    # Volver a Packing Station
    try {
        [Win32P5]::SetForegroundWindow($HandleSAP) | Out-Null
        Start-Sleep -Milliseconds 800
    }
    catch {
        Write-Host "ERROR: No se pudo volver a Packing Station."
        Write-Host "NO se ejecutara CTRL+S."
        Log "P7.1 ERROR - no se pudo reactivar Packing Station"
        return $false
    }

    # Guardar y salir del outbound
    Write-Host "Enviando CTRL+S para guardar y salir..."
    Log "P7.1 - enviando CTRL+S"
    [System.Windows.Forms.SendKeys]::SendWait("^s")

    Start-Sleep -Seconds 2

    Write-Host ""
    Write-Host "======================================================"
    Write-Host " P7.1 COMPLETADO"
    Write-Host "======================================================"
    Write-Host ""
    Write-Host "CTRL+P enviado desde Print:."
    Write-Host "CTRL+S enviado en Packing Station."
    Write-Host ""

    Log "P7.1 - impresion y guardado completados"
    return $true
}

# ============================================================
# FUNCION PARA LEER LOS PENDIENTES DEL ALV
#
# Se usa SOLO despues de terminar una vuelta completa.
# No se usa entre materiales.
# ============================================================

function Leer-PendientesALV {

    param(
        $SAP,
        $ALV
    )

    # ========================================================
    # VERIFICACION ROBUSTA
    #
    # SOLO LEE.
    # NO ESCRIBE MATERIAL.
    # NO ESCRIBE QTY.
    # NO ENVIA ENTER.
    #
    # Si la primera copia falla, vuelve a intentar la LECTURA.
    # ========================================================

    $maxIntentosLectura = 3

    for ($intento = 1; $intento -le $maxIntentosLectura; $intento++) {

        Write-Host ""
        Write-Host "Intento de lectura ALV: $intento de $maxIntentosLectura"

        Log "VERIFICACION - intento lectura $intento"

        # ----------------------------------------------------
        # VOLVER A BUSCAR EL ALV EN CADA INTENTO
        #
        # No confiamos en el AutomationElement anterior.
        # ----------------------------------------------------

        $ALVActual = $null

        try {

            $elementosActuales = $SAP.FindAll(
                [System.Windows.Automation.TreeScope]::Descendants,
                [System.Windows.Automation.Condition]::TrueCondition
            )

            foreach ($elementoActual in $elementosActuales) {

                try {

                    if ($elementoActual.Current.ClassName -eq "SAPALVGrid") {

                        $ALVActual = $elementoActual
                        break
                    }

                }
                catch {}
            }

        }
        catch {}

        if ($null -eq $ALVActual) {

            Write-Host "No se encontro SAPALVGrid en este intento."

            Log "VERIFICACION - ALV no encontrado intento=$intento"

            Start-Sleep -Seconds 2

            continue
        }

        # ----------------------------------------------------
        # ACTIVAR SAP
        # ----------------------------------------------------

        try {

            $handleLocal =
                [IntPtr]$SAP.Current.NativeWindowHandle

            [Win32P5]::SetForegroundWindow($handleLocal) |
                Out-Null

        }
        catch {

            Log "VERIFICACION - error activando SAP intento=$intento"

            Start-Sleep -Seconds 2

            continue
        }

        Start-Sleep -Milliseconds 1000

        # ----------------------------------------------------
        # OBTENER COORDENADAS DEL ALV NUEVO
        # ----------------------------------------------------

        try {

            $rectLocal =
                $ALVActual.Current.BoundingRectangle

            $alvXLocal =
                [int]$rectLocal.X

            $alvYLocal =
                [int]$rectLocal.Y

            $alvWidthLocal =
                [int]$rectLocal.Width

            $alvHeightLocal =
                [int]$rectLocal.Height

        }
        catch {

            Write-Host "No se pudieron obtener coordenadas del ALV."

            Log "VERIFICACION - BoundingRectangle fallo intento=$intento"

            Start-Sleep -Seconds 2

            continue
        }

        # Protección:
        # si SAP devuelve un rectángulo inválido, no hacemos clic.

        if (
            $alvWidthLocal -le 0 -or
            $alvHeightLocal -le 0
        ) {

            Write-Host "ALV detectado pero sin dimensiones validas."

            Log (
                "VERIFICACION - ALV dimensiones invalidas " +
                "intento=$intento"
            )

            Start-Sleep -Seconds 2

            continue
        }

        # ----------------------------------------------------
        # LIMPIAR PORTAPAPELES
        # ----------------------------------------------------

        try {

            [System.Windows.Forms.Clipboard]::Clear()

        }
        catch {}

        Start-Sleep -Milliseconds 300

        # ----------------------------------------------------
        # MISMO METODO DE LECTURA QUE FUNCIONA AL PRINCIPIO
        # ----------------------------------------------------

        $clickXLocal =
            $alvXLocal + [int]($alvWidthLocal * 0.50)

        $clickYLocal =
            $alvYLocal + 50

        Click-Mouse `
            -X $clickXLocal `
            -Y $clickYLocal

        Start-Sleep -Milliseconds 700

        [System.Windows.Forms.SendKeys]::SendWait("^a")

        Start-Sleep -Milliseconds 700

        [System.Windows.Forms.SendKeys]::SendWait("^c")

        # SAP/portapapeles puede tardar un poco.
        Start-Sleep -Milliseconds 1500

        # ----------------------------------------------------
        # OBTENER CONTENIDO
        # ----------------------------------------------------

        $contenidoLocal = ""

        try {

            if ([System.Windows.Forms.Clipboard]::ContainsText()) {

                $contenidoLocal =
                    [System.Windows.Forms.Clipboard]::GetText()
            }

        }
        catch {

            $contenidoLocal = ""
        }

        # ----------------------------------------------------
        # SI NO COPIO NADA, SOLO REPETIR LA LECTURA
        # ----------------------------------------------------

        if ([string]::IsNullOrWhiteSpace($contenidoLocal)) {

            Write-Host "El portapapeles quedo vacio."

            Log (
                "VERIFICACION - portapapeles vacio " +
                "intento=$intento"
            )

            if ($intento -lt $maxIntentosLectura) {

                Write-Host "Esperando para volver a intentar..."

                Start-Sleep -Seconds 2
            }

            continue
        }

        # ----------------------------------------------------
        # COPIA CONSEGUIDA
        # ----------------------------------------------------

        Write-Host "Tabla copiada correctamente."

        Log (
            "VERIFICACION - copia ALV correcta " +
            "intento=$intento"
        )

        # ----------------------------------------------------
        # INTERPRETAR TABLA
        #
        # Se conserva la misma logica que ya tenias.
        # ----------------------------------------------------

        $filasLocal =
            $contenidoLocal -split "`r?`n"

        $pendientesLocal = @()

        foreach ($filaLocal in $filasLocal) {

            if ([string]::IsNullOrWhiteSpace($filaLocal)) {
                continue
            }

            $columnasLocal =
                $filaLocal -split "`t"

            if ($columnasLocal.Count -lt 3) {
                continue
            }

            $correlativoLocal =
                $columnasLocal[0].Trim()

            $materialLocal =
                $columnasLocal[1].Trim()

            if ($materialLocal -eq "") {
                continue
            }

            $qtyLocal = $null

            for (
                $iLocal = 2;
                $iLocal -lt $columnasLocal.Count;
                $iLocal++
            ) {

                $valorLocal =
                    $columnasLocal[$iLocal].Trim()

                if (
                    $valorLocal -match
                    '^\d+(?:[\.,]\d+)?$'
                ) {

                    $valorNormalizadoLocal =
                        $valorLocal.Replace(",", ".")

                    $numeroQtyLocal = 0

                    $okLocal = [decimal]::TryParse(
                        $valorNormalizadoLocal,
                        [System.Globalization.NumberStyles]::Any,
                        [System.Globalization.CultureInfo]::InvariantCulture,
                        [ref]$numeroQtyLocal
                    )

                    if ($okLocal) {

                        $qtyLocal =
                            $numeroQtyLocal

                        break
                    }
                }
            }

            if (
                $null -ne $qtyLocal -and
                $qtyLocal -gt 0
            ) {

                $pendientesLocal += [PSCustomObject]@{
                    Correlativo = $correlativoLocal
                    Material    = $materialLocal
                    Qty         = $qtyLocal
                }
            }
        }

        # ----------------------------------------------------
        # LECTURA VALIDA
        #
        # Puede devolver:
        # 0 pendientes
        # o una lista de pendientes.
        # ----------------------------------------------------
	Write-Host (
	    "Lectura valida. Pendientes encontrados: " +
	    $pendientesLocal.Count
	)

	Log (
	    "VERIFICACION - lectura valida " +
	    "Pendientes=$($pendientesLocal.Count)"
	)

# ========================================================
# DEVOLVER RESULTADO ENVUELTO EN UN OBJETO
#
# Esto evita que PowerShell convierta una lista vacia
# de pendientes en $null.
# ========================================================

return [PSCustomObject]@{
    LecturaOK  = $true
    Pendientes = @($pendientesLocal)
}
        
    }

    # ========================================================
    # LOS 3 INTENTOS DE LECTURA FALLARON
    #
    # MUY IMPORTANTE:
    # devolvemos NULL, NO una lista vacia.
    #
    # De esa manera el programa NO confunde:
    #
    # "no pude verificar"
    #
    # con
    #
    # "verifique y hay 0 pendientes"
    # ========================================================

    Write-Host ""
    Write-Host "No fue posible leer el ALV despues de $maxIntentosLectura intentos."

    Log (
        "VERIFICACION FALLIDA - " +
        "$maxIntentosLectura intentos de lectura"
    )

    return $null
}

# ============================================================
# INICIAR LOG
# ============================================================

"P10 - PROCESAMIENTO MULTI OUTBOUND" |
    Out-File $archivo -Encoding UTF8

Log "P10 iniciado"

# ============================================================
# MOTOR P10 - PROCESAR UN OUTBOUND
# ============================================================

function Procesar-OutboundCompleto {

    param([Parameter(Mandatory=$true)][string]$Outbound)

    # Mantener $OB internamente para no modificar el motor P9/P7.1.
    $OB = $Outbound

    Write-Host ""
    Write-Host "Outbound recibido por el motor: $OB"
    Write-Host ""
    Log "P10 motor OB recibido=$OB"

# ============================================================
# BUSCAR VENTANA SAP
# ============================================================

Write-Host "Buscando Packing Station DELIVERY01..."

$root =
    [System.Windows.Automation.AutomationElement]::RootElement

$condVentana =
    New-Object System.Windows.Automation.PropertyCondition(
        [System.Windows.Automation.AutomationElement]::ControlTypeProperty,
        [System.Windows.Automation.ControlType]::Window
    )

$ventanas = $root.FindAll(
    [System.Windows.Automation.TreeScope]::Children,
    $condVentana
)

$SAP = $null

foreach ($ventana in $ventanas) {

    try {

        if (
            $ventana.Current.Name -match "Packing Station" -and
            $ventana.Current.ClassName -eq "SAP_FRONTEND_SESSION"
        ) {

            $SAP = $ventana
            break
        }

    }
    catch {}
}

if ($null -eq $SAP) {

    Write-Host ""
    Write-Host "ERROR: Packing Station no encontrado."

    Log "ERROR: Packing Station no encontrado"
    return "ERROR"
}

Write-Host "SAP encontrado."
Write-Host ""

Log "Packing Station encontrado"

# ============================================================
# P9 - ABRIR OUTBOUND EN SAP
#
# Logica tomada del P8 validado:
# activar Packing Station -> escribir OB -> ENTER -> esperar carga.
#
# A partir de BUSCAR ALV continua el motor P7.1.
# ============================================================

Write-Host "Abriendo Outbound $OB en SAP..."
Write-Host ""

try {

    $handleAbrirOB =
        [IntPtr]$SAP.Current.NativeWindowHandle

    [Win32P5]::ShowWindow(
        $handleAbrirOB,
        9
    ) | Out-Null

    Start-Sleep -Milliseconds 300

    [Win32P5]::SetForegroundWindow(
        $handleAbrirOB
    ) | Out-Null

    Start-Sleep -Milliseconds 700

}
catch {

    Write-Host "ERROR: No se pudo activar Packing Station."
    Log "P9 ERROR activando SAP para OB=$OB"
    return "ERROR"
}

Write-Host "Ingresando OB=$OB..."
Log "P9 ingresando OB=$OB"

[System.Windows.Forms.SendKeys]::SendWait(
    $OB
)

Start-Sleep -Milliseconds 500

Write-Host "Enviando ENTER..."
Log "P9 ENTER para OB=$OB"

[System.Windows.Forms.SendKeys]::SendWait(
    "{ENTER}"
)

Write-Host "Esperando que SAP cargue el Outbound..."
Start-Sleep -Seconds 3

Write-Host "Outbound $OB enviado a SAP."
Write-Host ""

Log "P9 OB=$OB enviado a SAP"

# ============================================================
# BUSCAR ALV
# ============================================================

$elementos = $SAP.FindAll(
    [System.Windows.Automation.TreeScope]::Descendants,
    [System.Windows.Automation.Condition]::TrueCondition
)

$ALV = $null

foreach ($elemento in $elementos) {

    try {

        if ($elemento.Current.ClassName -eq "SAPALVGrid") {

            $ALV = $elemento
            break
        }

    }
    catch {}
}

if ($null -eq $ALV) {

    Write-Host "ERROR: SAPALVGrid no encontrado."

    Log "ERROR: SAPALVGrid no encontrado"
    return "ERROR"
}

# ============================================================
# POSICION ALV
# ============================================================

$rect = $ALV.Current.BoundingRectangle

$alvX = [int]$rect.X
$alvY = [int]$rect.Y
$alvWidth = [int]$rect.Width
$alvHeight = [int]$rect.Height

Write-Host "ALV encontrado."
Write-Host ""

# ============================================================
# ACTIVAR SAP
# ============================================================

$handle = [IntPtr]$SAP.Current.NativeWindowHandle

[Win32P5]::ShowWindow($handle, 9) | Out-Null

Start-Sleep -Milliseconds 500

[Win32P5]::SetForegroundWindow($handle) | Out-Null

Start-Sleep -Milliseconds 700

# ============================================================
# LEER ALV UNA SOLA VEZ
#
# BLOQUE ORIGINAL FUNCIONAL
# ============================================================

Write-Host "Leyendo tabla completa..."

try {
    [System.Windows.Forms.Clipboard]::Clear()
}
catch {}

$clickX = $alvX + [int]($alvWidth * 0.50)
$clickY = $alvY + 50

Click-Mouse -X $clickX -Y $clickY

Start-Sleep -Milliseconds 500

[System.Windows.Forms.SendKeys]::SendWait("^a")

Start-Sleep -Milliseconds 500

[System.Windows.Forms.SendKeys]::SendWait("^c")

Start-Sleep -Seconds 1

$contenido = ""

try {

    if ([System.Windows.Forms.Clipboard]::ContainsText()) {

        $contenido =
            [System.Windows.Forms.Clipboard]::GetText()
    }

}
catch {}

if ([string]::IsNullOrWhiteSpace($contenido)) {

    Write-Host ""
    Write-Host "ERROR: No se obtuvieron datos del ALV."

    Log "ERROR: portapapeles vacio"
    return "ERROR"
}

# ============================================================
# INTERPRETAR TABLA
#
# BLOQUE ORIGINAL FUNCIONAL
# ============================================================

$filas = $contenido -split "`r?`n"

$pendientes = @()

foreach ($fila in $filas) {

    if ([string]::IsNullOrWhiteSpace($fila)) {
        continue
    }

    $columnas = $fila -split "`t"

    if ($columnas.Count -lt 3) {
        continue
    }

    $correlativo = $columnas[0].Trim()
    $material = $columnas[1].Trim()

    if ($material -eq "") {
        continue
    }

    $qty = $null

    for ($i = 2; $i -lt $columnas.Count; $i++) {

        $valor = $columnas[$i].Trim()

        if ($valor -match '^\d+(?:[\.,]\d+)?$') {

            $valorNormalizado =
                $valor.Replace(",", ".")

            $numeroQty = 0

            $ok = [decimal]::TryParse(
                $valorNormalizado,
                [System.Globalization.NumberStyles]::Any,
                [System.Globalization.CultureInfo]::InvariantCulture,
                [ref]$numeroQty
            )

            if ($ok) {

                $qty = $numeroQty
                break
            }
        }
    }

    if (
        $null -ne $qty -and
        $qty -gt 0
    ) {

        $pendientes += [PSCustomObject]@{
            Correlativo = $correlativo
            Material    = $material
            Qty         = $qty
        }
    }
}

# ============================================================
# RESULTADO INICIAL
# ============================================================

Write-Host ""
Write-Host "======================================================"
Write-Host " OUTBOUND LEIDO"
Write-Host "======================================================"
Write-Host ""
Write-Host "Filas encontradas     : $($filas.Count)"
Write-Host "Materiales pendientes : $($pendientes.Count)"
Write-Host ""

if ($pendientes.Count -eq 0) {

    Write-Host "No hay materiales pendientes."
    Write-Host "Se omitira el procesamiento y NO se imprimira etiqueta."
    Log "P10 SIN_PENDIENTES OB=$OB"

    # Regresar a la pantalla lista para recibir el siguiente Delivery.
    try {
        [Win32P5]::SetForegroundWindow($handle) | Out-Null
        Start-Sleep -Milliseconds 700
        [System.Windows.Forms.SendKeys]::SendWait("^s")
        Start-Sleep -Seconds 2
        Log "P10 OB=$OB omitido - CTRL+S enviado para continuar"
    }
    catch {
        Log "P10 ERROR saliendo de OB sin pendientes=$OB"
        return "ERROR"
    }

    return "SIN_PENDIENTES"
}

$totalPiezas = 0

foreach ($p in $pendientes) {
    $totalPiezas += $p.Qty
}

Write-Host "Piezas pendientes     : $totalPiezas"
Write-Host ""

Write-Host "LISTA QUE SE PROCESARA:"
Write-Host ""

foreach ($p in $pendientes) {

    Write-Host (
        "  {0,-5} {1,-18} Qty: {2}" -f
        $p.Correlativo,
        $p.Material,
        $p.Qty
    )

    Log (
        "PENDIENTE Correlativo=$($p.Correlativo) " +
        "Material=$($p.Material) Qty=$($p.Qty)"
    )
}

Write-Host ""
Write-Host "======================================================"
Write-Host " CONFIRMACION"
Write-Host "======================================================"
Write-Host ""
Write-Host "Esta es la UNICA confirmacion del proceso."
Write-Host ""
Write-Host "Despues de iniciar:"
Write-Host ""
Write-Host " - NO uses el mouse"
Write-Host " - NO uses el teclado"
Write-Host " - NO cambies de ventana"
Write-Host ""
Write-Host "El robot recorrera toda la lista."
Write-Host ""

$confirmacion = "PROCESAR"
if ($confirmacion -ne "PROCESAR") {

    Write-Host "Cancelado."

    Log "Cancelado por usuario"
    return "ERROR"
}

# ============================================================
# POSICION DEL MATERIAL
#
# EXACTAMENTE la utilizada por P4.
# ============================================================

$sapRect = $SAP.Current.BoundingRectangle

$sapX = [int]$sapRect.X
$sapY = [int]$sapRect.Y

$materialX = $sapX + 440
$materialY = $sapY + 235

# ============================================================
# PRIMERA VUELTA
#
# ESTE ES EL BLOQUE FUNCIONAL ORIGINAL.
# NO SE MODIFICA SU MECANICA.
# ============================================================

$contador = 0
$errores = 0

foreach ($actual in $pendientes) {

    $contador++

    $correlativo = $actual.Correlativo
    $material = $actual.Material
    $qty = $actual.Qty

    $qtyTexto = $qty.ToString(
        [System.Globalization.CultureInfo]::InvariantCulture
    )

    Write-Host ""
    Write-Host "------------------------------------------------------"
    Write-Host " [$contador / $($pendientes.Count)]"
    Write-Host "------------------------------------------------------"
    Write-Host "Correlativo : $correlativo"
    Write-Host "Material    : $material"
    Write-Host "Qty         : $qtyTexto"
    Write-Host ""

    Log (
        "INICIO #$contador " +
        "Correlativo=$correlativo " +
        "Material=$material " +
        "Qty=$qtyTexto"
    )

    # ========================================================
    # MISMA SECUENCIA DE P4
    # ========================================================

    [Win32P5]::SetForegroundWindow($handle) | Out-Null

    Start-Sleep -Milliseconds $esperaAntesMaterial

    # --------------------------------------------------------
    # CLIC MATERIAL
    # --------------------------------------------------------

    Click-Mouse -X $materialX -Y $materialY

    Start-Sleep -Milliseconds $esperaDespuesClick

    # --------------------------------------------------------
    # CTRL+A
    # --------------------------------------------------------

    [System.Windows.Forms.SendKeys]::SendWait("^a")

    Start-Sleep -Milliseconds 100

    # --------------------------------------------------------
    # MATERIAL
    # --------------------------------------------------------

    [System.Windows.Forms.SendKeys]::SendWait($material)

    Start-Sleep -Milliseconds $esperaDespuesEscribirMaterial

    # --------------------------------------------------------
    # ENTER MATERIAL
    # --------------------------------------------------------

    [System.Windows.Forms.SendKeys]::SendWait("{ENTER}")

    Start-Sleep -Milliseconds $esperaDespuesEnterMaterial

    # --------------------------------------------------------
    # QTY
    # --------------------------------------------------------

    [Win32P5]::SetForegroundWindow($handle) | Out-Null

    Start-Sleep -Milliseconds $esperaAntesQty

    [System.Windows.Forms.SendKeys]::SendWait($qtyTexto)

    Start-Sleep -Milliseconds $esperaDespuesQty

    # --------------------------------------------------------
    # ENTER FINAL = PACKING
    # --------------------------------------------------------

    [System.Windows.Forms.SendKeys]::SendWait("{ENTER}")

    Start-Sleep -Milliseconds $esperaDespuesPacking

    Log (
        "ENVIADO #$contador " +
        "Material=$material Qty=$qtyTexto"
    )

    Write-Host "Enviado."
}

# ============================================================
# PRIMERA VUELTA TERMINADA
# ============================================================

Write-Host ""
Write-Host "======================================================"
Write-Host " PRIMERA VUELTA TERMINADA"
Write-Host "======================================================"
Write-Host ""
Write-Host "Materiales enviados : $contador"
Write-Host "Piezas previstas    : $totalPiezas"
Write-Host ""
Write-Host "Esperando antes de verificar..."
Write-Host ""

Log "PRIMERA VUELTA TERMINADA Materiales=$contador Piezas=$totalPiezas"

Start-Sleep -Milliseconds $esperaAntesVerificacion

# ============================================================
# VOLVER A LOCALIZAR EL ALV
# ============================================================

$elementosVerificacion = $SAP.FindAll(
    [System.Windows.Automation.TreeScope]::Descendants,
    [System.Windows.Automation.Condition]::TrueCondition
)

$ALVVerificacion = $null

foreach ($elementoVerificacion in $elementosVerificacion) {

    try {

        if (
            $elementoVerificacion.Current.ClassName -eq
            "SAPALVGrid"
        ) {

            $ALVVerificacion = $elementoVerificacion
            break
        }

    }
    catch {}
}

if ($null -eq $ALVVerificacion) {

    Write-Host ""
    Write-Host "ERROR: No se encontro ALV para verificar."
    Write-Host "El robot se detendra."

    Log "ERROR: ALV no encontrado para verificacion"
    return "ERROR"
}

# ============================================================
# PRIMERA VERIFICACION
# ============================================================

Write-Host "Realizando verificacion de Qty not pckd..."

$resultadoVerificacion =
    Leer-PendientesALV `
        -SAP $SAP `
        -ALV $ALVVerificacion

if ($null -eq $resultadoVerificacion) {

    Write-Host ""
    Write-Host "ERROR: No fue posible realizar la verificacion."
    Write-Host "El robot se detendra."

    Log "ERROR: lectura de verificacion fallida"
    return "ERROR"
}

$pendientesRespaldo =
    @($resultadoVerificacion.Pendientes)

# ============================================================
# SI TODO QUEDO EN 0
# ============================================================

if ($pendientesRespaldo.Count -eq 0) {

    Write-Host ""
    Write-Host "======================================================"
    Write-Host " VERIFICACION CORRECTA"
    Write-Host "======================================================"
    Write-Host ""
    Write-Host "No quedan materiales con Qty not pckd."
    Write-Host ""
    Write-Host "Pendientes finales : 0"
    Write-Host ""
    Log "VERIFICACION OK - Pendientes=0"

    $resultadoP7 =
        Finalizar-OutboundP7 `
            -SAP $SAP `
            -HandleSAP $handle

    if ($resultadoP7) {
        Log "P10 OB=$OB finalizado correctamente"
        return "OK"
    }
    else {
        Log "P10 OB=$OB detenido durante impresion/guardado"
        return "ERROR"
    }
}

# ============================================================
# SE ENCONTRARON PENDIENTES
# ============================================================

Write-Host ""
Write-Host "======================================================"
Write-Host " RECUPERACION NECESARIA"
Write-Host "======================================================"
Write-Host ""
Write-Host "Quedaron materiales pendientes:"
Write-Host ""

$totalRespaldo = 0

foreach ($p in $pendientesRespaldo) {

    $totalRespaldo += $p.Qty

    Write-Host (
        "  {0,-5} {1,-18} Qty: {2}" -f
        $p.Correlativo,
        $p.Material,
        $p.Qty
    )

    Log (
        "PENDIENTE RESPALDO " +
        "Correlativo=$($p.Correlativo) " +
        "Material=$($p.Material) " +
        "Qty=$($p.Qty)"
    )
}

Write-Host ""
Write-Host "Materiales pendientes : $($pendientesRespaldo.Count)"
Write-Host "Piezas pendientes     : $totalRespaldo"
Write-Host ""
Write-Host "Se realizara UNA UNICA pasada de recuperacion."
Write-Host ""

Log (
    "INICIO RECUPERACION " +
    "Materiales=$($pendientesRespaldo.Count) " +
    "Piezas=$totalRespaldo"
)

Start-Sleep -Seconds 2

# ============================================================
# PASADA DE RECUPERACION
#
# IMPORTANTE:
# MISMA MECANICA EXACTA DEL BLOQUE FUNCIONAL.
# ============================================================

$contadorRespaldo = 0

foreach ($actual in $pendientesRespaldo) {

    $contadorRespaldo++

    $correlativo = $actual.Correlativo
    $material = $actual.Material
    $qty = $actual.Qty

    $qtyTexto = $qty.ToString(
        [System.Globalization.CultureInfo]::InvariantCulture
    )

    Write-Host ""
    Write-Host "------------------------------------------------------"
    Write-Host " RECUPERACION [$contadorRespaldo / $($pendientesRespaldo.Count)]"
    Write-Host "------------------------------------------------------"
    Write-Host "Correlativo : $correlativo"
    Write-Host "Material    : $material"
    Write-Host "Qty         : $qtyTexto"
    Write-Host ""

    Log (
        "RECUPERACION INICIO #$contadorRespaldo " +
        "Correlativo=$correlativo " +
        "Material=$material " +
        "Qty=$qtyTexto"
    )

    # ========================================================
    # MISMA SECUENCIA FUNCIONAL
    # ========================================================

    [Win32P5]::SetForegroundWindow($handle) | Out-Null

    Start-Sleep -Milliseconds $esperaAntesMaterial

    # CLIC MATERIAL

    Click-Mouse -X $materialX -Y $materialY

    Start-Sleep -Milliseconds $esperaDespuesClick

    # CTRL+A

    [System.Windows.Forms.SendKeys]::SendWait("^a")

    Start-Sleep -Milliseconds 100

    # MATERIAL

    [System.Windows.Forms.SendKeys]::SendWait($material)

    Start-Sleep -Milliseconds $esperaDespuesEscribirMaterial

    # ENTER MATERIAL

    [System.Windows.Forms.SendKeys]::SendWait("{ENTER}")

    Start-Sleep -Milliseconds $esperaDespuesEnterMaterial

    # QTY

    [Win32P5]::SetForegroundWindow($handle) | Out-Null

    Start-Sleep -Milliseconds $esperaAntesQty

    [System.Windows.Forms.SendKeys]::SendWait($qtyTexto)

    Start-Sleep -Milliseconds $esperaDespuesQty

    # ENTER FINAL

    [System.Windows.Forms.SendKeys]::SendWait("{ENTER}")

    Start-Sleep -Milliseconds $esperaDespuesPacking

    Log (
        "RECUPERACION ENVIADO #$contadorRespaldo " +
        "Material=$material Qty=$qtyTexto"
    )

    Write-Host "Enviado."
}

# ============================================================
# RECUPERACION TERMINADA
# ============================================================

Write-Host ""
Write-Host "======================================================"
Write-Host " RECUPERACION TERMINADA"
Write-Host "======================================================"
Write-Host ""
Write-Host "Materiales reenviados : $contadorRespaldo"
Write-Host "Piezas reenviadas     : $totalRespaldo"
Write-Host ""
Write-Host "Realizando verificacion final..."
Write-Host ""

Log (
    "RECUPERACION TERMINADA " +
    "Materiales=$contadorRespaldo " +
    "Piezas=$totalRespaldo"
)

Start-Sleep -Milliseconds $esperaAntesVerificacion

# ============================================================
# VOLVER A LOCALIZAR ALV PARA VERIFICACION FINAL
# ============================================================

$elementosFinal = $SAP.FindAll(
    [System.Windows.Automation.TreeScope]::Descendants,
    [System.Windows.Automation.Condition]::TrueCondition
)

$ALVFinal = $null

foreach ($elementoFinal in $elementosFinal) {

    try {

        if ($elementoFinal.Current.ClassName -eq "SAPALVGrid") {

            $ALVFinal = $elementoFinal
            break
        }

    }
    catch {}
}

if ($null -eq $ALVFinal) {

    Write-Host ""
    Write-Host "ERROR: No se encontro ALV para verificacion final."

    Log "ERROR: ALV no encontrado en verificacion final"
    return "ERROR"
}

# ============================================================
# VERIFICACION FINAL
# ============================================================

$resultadoFinal =
    Leer-PendientesALV `
        -SAP $SAP `
        -ALV $ALVFinal

if ($null -eq $resultadoFinal) {

    Write-Host ""
    Write-Host "ERROR: No se pudo realizar la verificacion final."

    Log "ERROR: lectura final fallida"
    return "ERROR"
}

$pendientesFinales =
    @($resultadoFinal.Pendientes)

# ============================================================
# RESULTADO FINAL
# ============================================================

if ($pendientesFinales.Count -eq 0) {

    Write-Host ""
    Write-Host "======================================================"
    Write-Host " OUTBOUND COMPLETADO"
    Write-Host "======================================================"
    Write-Host ""
    Write-Host "La pasada de recuperacion funciono."
    Write-Host ""
    Write-Host "Pendientes finales : 0"
    Write-Host ""

    Log "VERIFICACION FINAL OK - Pendientes=0"

    $resultadoP7 =
        Finalizar-OutboundP7 `
            -SAP $SAP `
            -HandleSAP $handle

    if ($resultadoP7) {
        Log "P10 OB=$OB finalizado correctamente despues de recuperacion"
        return "OK"
    }
    else {
        Log "P10 OB=$OB detenido durante impresion/guardado despues de recuperacion"
        return "ERROR"
    }
}
else {

    Write-Host ""
    Write-Host "======================================================"
    Write-Host " QUEDAN PENDIENTES"
    Write-Host "======================================================"
    Write-Host ""
    Write-Host "La recuperacion ya fue ejecutada UNA vez."
    Write-Host ""
    Write-Host "El robot NO volvera a intentarlo."
    Write-Host ""
    Write-Host "Pendientes:"
    Write-Host ""

    $totalFinal = 0

    foreach ($p in $pendientesFinales) {

        $totalFinal += $p.Qty

        Write-Host (
            "  {0,-5} {1,-18} Qty: {2}" -f
            $p.Correlativo,
            $p.Material,
            $p.Qty
        )

        Log (
            "PENDIENTE FINAL " +
            "Correlativo=$($p.Correlativo) " +
            "Material=$($p.Material) " +
            "Qty=$($p.Qty)"
        )
    }

    Write-Host ""
    Write-Host "Materiales pendientes : $($pendientesFinales.Count)"
    Write-Host "Piezas pendientes     : $totalFinal"
    Write-Host ""
    Write-Host "REVISA ESTOS MATERIALES MANUALMENTE."
    Write-Host ""

    Log (
        "P5 TERMINADO CON PENDIENTES " +
        "Materiales=$($pendientesFinales.Count) " +
        "Piezas=$totalFinal"
    )
}


    Log "P10 OB=$OB terminado con pendientes que requieren revision"
    return "PENDIENTES"
}


# ============================================================
# P10 - LISTA / ARRAY DE OUTBOUNDS
# ============================================================

Write-Host ""
Write-Host "======================================================"
Write-Host " P10 - PROCESAMIENTO MULTI OUTBOUND"
Write-Host "======================================================"
Write-Host ""
Write-Host "Ingresa un Outbound Delivery por linea."
Write-Host "Para esta prueba debes ingresar AL MENOS 3."
Write-Host "Escribe FIN cuando termines."
Write-Host ""

$listaOB = New-Object System.Collections.Generic.List[string]

while ($true) {

    $entrada = (Read-Host "Outbound").Trim()

    if ($entrada.ToUpper() -eq "FIN") {

        if ($listaOB.Count -lt 3) {
            Write-Host ""
            Write-Host "Debes ingresar al menos 3 Outbound Deliveries."
            Write-Host "Actualmente hay: $($listaOB.Count)"
            Write-Host ""
            continue
        }

        break
    }

    if ([string]::IsNullOrWhiteSpace($entrada)) { continue }

    if ($entrada -notmatch "^\d+$") {
        Write-Host "ERROR: El Outbound debe contener solamente numeros."
        continue
    }

    if ($listaOB.Contains($entrada)) {
        Write-Host "Ese Outbound ya esta en la lista."
        continue
    }

    $listaOB.Add($entrada)
    Write-Host "Agregado: $entrada"
    Log "P10 OB agregado=$entrada"
}

$cantidadOB = $listaOB.Count

Write-Host ""
Write-Host "======================================================"
Write-Host " LISTA DE OUTBOUNDS"
Write-Host "======================================================"
Write-Host ""

for ($i = 0; $i -lt $cantidadOB; $i++) {
    Write-Host "$($i + 1). $($listaOB[$i])"
}

Write-Host ""
Write-Host "Total: $cantidadOB"
Write-Host ""

$confirmacionLote = Read-Host "Escribe INICIAR para procesar el lote"

if ($confirmacionLote.ToUpper() -ne "INICIAR") {
    Write-Host "Operacion cancelada."
    Log "P10 lote cancelado por usuario"
    exit
}

$resultados = @()

for ($i = 0; $i -lt $cantidadOB; $i++) {

    $OBActual = $listaOB[$i]
    $numeroActual = $i + 1

    Write-Host ""
    Write-Host "======================================================"
    Write-Host " OB #$numeroActual DE $cantidadOB"
    Write-Host " OUTBOUND: $OBActual"
    Write-Host "======================================================"
    Write-Host ""

    Log "P10 INICIO OB #$numeroActual/$cantidadOB OB=$OBActual"

    $estado = Procesar-OutboundCompleto -Outbound $OBActual

    # Proteccion: si el motor no devuelve estado, tratarlo como ERROR.
    if ([string]::IsNullOrWhiteSpace([string]$estado)) {
        $estado = "ERROR"
        Log "P10 ERROR - motor devolvio estado vacio para OB=$OBActual"
    }

    $resultados += [PSCustomObject]@{
        Numero   = $numeroActual
        Outbound = $OBActual
        Estado   = $estado
    }

    Log "P10 FIN OB=$OBActual Estado=$estado"

    Write-Host ""
    Write-Host "Resultado OB $OBActual : $estado"
    Write-Host ""

    # ERROR o pendientes residuales detienen el lote por seguridad.
    if ($estado -eq "ERROR" -or $estado -eq "PENDIENTES") {
        Write-Host "El lote se detendra por seguridad."
        Write-Host "Revisa SAP antes de continuar manualmente."
        Log "P10 LOTE DETENIDO OB=$OBActual Estado=$estado"
        break
    }

    if ($i -lt ($cantidadOB - 1)) {
        Write-Host "Continuando con el siguiente Outbound..."
        Start-Sleep -Seconds 2
    }
}

Write-Host ""
Write-Host "======================================================"
Write-Host " RESUMEN P10"
Write-Host "======================================================"
Write-Host ""

foreach ($r in $resultados) {
    Write-Host ("#{0,-3} OB {1,-15} {2}" -f $r.Numero, $r.Outbound, $r.Estado)
}

$ok = @($resultados | Where-Object { $_.Estado -eq "OK" }).Count
$sinPendientes = @($resultados | Where-Object { $_.Estado -eq "SIN_PENDIENTES" }).Count
$errores = @($resultados | Where-Object { $_.Estado -eq "ERROR" }).Count
$conPendientes = @($resultados | Where-Object { $_.Estado -eq "PENDIENTES" }).Count

Write-Host ""
Write-Host "Correctos       : $ok"
Write-Host "Sin pendientes  : $sinPendientes"
Write-Host "Errores         : $errores"
Write-Host "Con pendientes  : $conPendientes"
Write-Host ""

Log "P10 RESUMEN OK=$ok SIN_PENDIENTES=$sinPendientes ERROR=$errores PENDIENTES=$conPendientes"

Read-Host "Presiona ENTER para cerrar"
